import { test, expect } from '@playwright/test';
import { CommonUtils } from '../tests/pageObjects/Commonutils';
import { LoginPage } from '../tests/pageObjects/LoginPage';
import { DashboardPage } from '../tests/pageObjects/DashboardPage';


test('Section_11_RS_UI_Tests - RahulShettyAcademy Client App Login - POM_Login_Assert_Msg_LoginSuccess', async ({page} )=> {

    const data_login_username = "likhit1993@gmail.com";
    const data_login_password = "2024@Bhubaneswa";

    /****************** Login Page - START *******************/
    
    const loginPage = new LoginPage(page);
    await loginPage.goToApplication();
    await loginPage.loginToApplication(data_login_username,data_login_password);

    /****************** Login Page - END *******************/
 
    /****************** Dashboard Page - START *******************/
    const dashboardPage = new DashboardPage(page);
    
    console.log('Assertions for message: Login Successfully')
    await dashboardPage.getMsg_LoginSuccess().waitFor();
    await expect(dashboardPage.getMsg_LoginSuccess()).toBeVisible();

    await expect(dashboardPage.getMsg_LoginSuccess()).toHaveText('Login Successfully');
    await expect(dashboardPage.getMsg_LoginSuccess()).toContainText('Successfully');

    /****************** Dashboard Page - END *******************/

    //await page.pause();
});

test.afterEach(async() => {
    await new CommonUtils().waitForSomeTime(5);
});