import { test, expect } from '@playwright/test';


test('Capture Network Requests after Purchase', async ({ page }) => {
    // Intercept network requests
    const capturedRequests = [];
    page.on('request', request => {
        capturedRequests.push(request.url());
    });

    // Navigate to the webpage
    await page.goto("https://bar.bagconsult.eu/");
    const jumbotronDiv = await page.locator('.jumbotron');
    const jumbotronText = await jumbotronDiv.textContent();
    console.log(jumbotronText);
    expect(jumbotronText).toMatch(/Place your order|Bobcho's Bar|Welcome to Bobcho's bar\. We are here to serve your needs|Purchase »/);



    // Click on the "Purchase" button
    await page.locator(".btn.btn-primary.btn-lg").click();


    // Take a screenshot after clicking on the button
    await page.screenshot({ path: 'screenshot1.png' });

    // Select an option in a dropdown menu
    await page.selectOption('#Size', { value: '1' });

    // Take a screenshot after selecting the option
    await page.screenshot({ path: 'screenshot2.png' });

    // Click on an input field and enter text
    await page.locator("#Qty").click();
    await page.locator("#Qty").fill("4");

    // Take a screenshot after entering text
    await page.screenshot({ path: 'screenshot3.png' });

    // Click on another input field and enter text
    await page.locator("#Name").click();
    await page.locator("#Name").fill("XYZ");

    // Take a screenshot after entering text
    await page.screenshot({ path: 'screenshot4.png' });

    // Click on an email input field and enter text
    await page.locator("#Email").click();
    await page.locator("#Email").fill("XYZ");

    // Take a screenshot after entering text
    await page.screenshot({ path: 'screenshot5.png' });

    // Click on a checkbox
    await page.locator("#IsAdult").click();

    // Take a screenshot after clicking on the checkbox
    await page.screenshot({ path: 'screenshot6.png' });

    // Click on a button to submit the form
    await page.locator("#btnOrder").click();

    // Wait for a short while to allow requests to be captured
    await page.waitForTimeout(2000); // Adjust the timeout as needed

    // Log the captured requests
    console.log("Captured Requests:", capturedRequests);

    const orderId = capturedRequests
    .find(url => url.includes('/api/Order/'))
    .split('/')
    .pop();
    
    // Log the orderId if found
    if (orderId) {
        console.log("Order ID:", orderId);
    } else {
        console.log("No order ID found in requests containing '/Purchase/Confirm/'.");
    }

    
const h1Text = await page.textContent('div.jumbotron h1');
expect(h1Text).toContain('Order confirmation');
const pText = await page.textContent('div.jumbotron p.lead');
expect(pText).toContain('Thank you for your order. You can find the details below.');


});


