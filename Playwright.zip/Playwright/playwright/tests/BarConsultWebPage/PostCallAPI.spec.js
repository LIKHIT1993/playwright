import { test, expect } from '@playwright/test';

test('Make API request with Playwright', async ({ page }) => {
  const payload = {
    "IsAdult": true,
    "Quantity": 1,
    "Name": "XYZ",
    "Email": "XYZ",
  };
  
  const url = 'https://bar.bagconsult.eu/api/Order/';

  const response = await page.evaluate(async ({ url, payload }) => {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    });
    return response.json();
  }, { url, payload });

  console.log('API response:', response);

  // Assert on the response if needed
  expect(response).toBeDefined();
});
