const { test, expect, request } = require('@playwright/test');

let api_login_token;
let orderId; // Change const to let

const requestBody_Login = {
    userEmail: "likhit1993@gmail.com",
    userPassword: "2024@Bhubaneswa"
};

const requestBody_createOrder = {
    orders: [
        {
            country: "Cuba",
            productOrderedId: "6581ca399fd99c85e8ee7f45"
        }
    ]
};

test.beforeAll(async () => {
    const apiContext = await request.newContext({
        ignoreHTTPSErrors: true
    });

    const response_login = await apiContext.post(
        'https://www.rahulshettyacademy.com/api/ecom/auth/login',
        {
            data: requestBody_Login
        });

    expect(response_login.ok()).toBeTruthy();
    
    const response_login_json = await response_login.json();
    api_login_token = response_login_json.token;

    console.log('api_login_token: ' + api_login_token);

    const orderresponse = await apiContext.post(
        'https://rahulshettyacademy.com/api/ecom/order/create-order',
        {
            data: requestBody_createOrder,
            headers: {
                'Authorization': api_login_token,
                'Content-Type': 'application/json'
            },
        });

    const orderresponsejson = await orderresponse.json();
    console.log(orderresponsejson);
    orderId = orderresponsejson.orders[0];
});

test.beforeEach(async ({ page }) => {
    // Your beforeEach logic
});

test('@Client App login', async ({ page }) => {
    page.addInitScript(value => {
        window.localStorage.setItem('token', value);
    }, api_login_token);

    const email = "likhit1993@gmail.com";
    const productName = 'ZARA COAT 3';
    const products = page.locator(".card-body");

    const applicationURL = "https://www.rahulshettyacademy.com/client/";
    await page.goto(applicationURL);
    
    await page.locator(".btn.btn-custom[routerlink='/dashboard/myorders']").click();
    const verifyOrderID = page.locator("tr.ng-star-inserted");
    const verifyOrderValue = await verifyOrderID.locator('th[scope="row"]').first().textContent();

    const cleanedTrimmedValue = verifyOrderValue.replace(/\s+/g, '');
    const cleanedTargetString = orderId.replace(/\|/g, '').replace(/\s+/g, '');

    if (cleanedTrimmedValue === cleanedTargetString) {
        await page.waitForSelector("td button.btn-primary");
        await page.locator("td button.btn-primary").first().click();
        return;
    }

    const orderIdDetails = await page.locator(".col-text").textContent();
    expect(orderId.includes(orderIdDetails)).toBeTruthy();

    await page.pause();
});
