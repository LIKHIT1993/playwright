import { test, expect } from '@playwright/test';


test('Capture Network Requests after Purchase', async ({ page }) => {
    // Intercept network requests
    const capturedRequests = [];
    page.on('request', request => {
        capturedRequests.push(request.url());
    });

    // Navigate to the webpage
    await page.goto("https://bar.bagconsult.eu/");

    // Click on the "Purchase" button
    await page.locator(".btn.btn-primary.btn-lg").click();


    // Take a screenshot after clicking on the button
    await page.screenshot({ path: 'screenshot1.png' });

    // Select an option in a dropdown menu
    await page.selectOption('#Size', { value: '1' });

    // Take a screenshot after selecting the option
    await page.screenshot({ path: 'screenshot2.png' });

    // Click on an input field and enter text
    await page.locator("#Qty").click();
    await page.locator("#Qty").fill("4");

    // Take a screenshot after entering text
    await page.screenshot({ path: 'screenshot3.png' });

    // Click on another input field and enter text
    await page.locator("#Name").click();
    await page.locator("#Name").fill("XYZ");

    // Take a screenshot after entering text
    await page.screenshot({ path: 'screenshot4.png' });

    // Click on an email input field and enter text
    await page.locator("#Email").click();
    await page.locator("#Email").fill("XYZ");

    // Take a screenshot after entering text
    await page.screenshot({ path: 'screenshot5.png' });

    // Click on a checkbox
    await page.locator("#IsAdult").click();

    // Take a screenshot after clicking on the checkbox
    await page.screenshot({ path: 'screenshot6.png' });

    // Click on a button to submit the form
    await page.locator("#btnOrder").click();

    // Wait for a short while to allow requests to be captured
    await page.waitForTimeout(2000); // Adjust the timeout as needed

    // Log the captured requests
    console.log("Captured Requests:", capturedRequests);

   // Get - Request Extract the order ID from the captured request URL
   const orderId = capturedRequests
   .find(url => url.includes('/Purchase/Confirm/'))
   .split('/')
   .pop();

if (orderId) {
   try {
       // Make a GET request to the '/api/order/' endpoint using Playwright's fetch API
       const response = await page.evaluate(async (orderId) => {
           const res = await fetch(`https://bar.bagconsult.eu/api/order/${orderId}`);
           return await res.json();
       }, orderId);

       // Log the response data
       console.log("GET Request Response:", response);
   } catch (error) {
       console.error("Error fetching order details:", error);
   }
} else {
   console.log("No order ID found in the captured requests.");
}

    //Get Request for all orderId
if (orderId) {
    try {
        // Make a GET request to the '/api/order/' endpoint using Playwright's fetch API
        const response = await page.evaluate(async (orderId) => {
            const res = await fetch(`https://bar.bagconsult.eu/api/order/`);
            return await res.json();
        }, orderId);
 
        // Log the response data
        console.log("GET Request Response:", response);
    } catch (error) {
        console.error("Error fetching order details:", error);
    }
 } else {
    console.log("No order ID found in the captured requests.");
 }



// Put - Request 
if (orderId) {
    try {
        const updatedDetails = {
            Quantity: 4, // Update quantity if necessary
            Name: 'XYZ12', // Update name if necessary
            Email: 'XYZ12', // Update email if necessary
        };

        const response = await page.evaluate(async ({ orderId, updatedDetails }) => {
            const res = await fetch(`https://bar.bagconsult.eu/api/order/${orderId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(updatedDetails)
            });
            return await res.text(); // Get response text
        }, { orderId, updatedDetails });

        console.log("Response from server:", response); // Log response

        try {
            const jsonResponse = JSON.parse(response); // Try to parse response as JSON
            console.log("Order details updated successfully:", jsonResponse);
        } catch (error) {
            console.error("Error parsing JSON response:", error);
        }
    } catch (error) {
        console.error("Error updating order details:", error);
    }
} else {
    console.log("No order ID found in the captured requests.");
}


});
