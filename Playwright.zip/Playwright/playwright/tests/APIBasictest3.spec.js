import { test, expect, request, browserContext } from '@playwright/test';
import { APIUtils } from '/Users/likhit.panigrahi/Library/CloudStorage/OneDrive-UKG/Documents/Playwright/utils/APiUtils.js';

const fakePayLoadOrders = { data: [], message: "No Orders" };
const requestBody_Login = {
    userEmail: "likhit1993@gmail.com", 
    userPassword: "2024@Bhubaneswa"
};

const requestBody_createOrder = {
    orders: [
        {
            country: "Cuba",
            productOrderedId: "6581ca399fd99c85e8ee7f45"
        }
    ]
};

let response;

test.beforeAll(async () => {
  const apiContext = await request.newContext({ ignoreHTTPSErrors: true });
  const apiUtils = new APIUtils(apiContext, requestBody_Login);
  response = await apiUtils.createOrder(requestBody_createOrder);
  console.log('Response from createOrder:', response);


});


  test.beforeEach(async ({ page }) => {
    const applicationURL = "https://rahulshettyacademy.com/client/dashboard/dash";

    // Set a cookie with the token for a dummy URL
    await page.context().addCookies([
      {
          name: 'token',
          value: response.token,
          domain: 'rahulshettyacademy.com', // Specify the domain of your application
          path: '/', // Specify the path
          expires: 0, // Session cookie
          httpOnly: false, // Adjust as needed
          secure: false // Adjust as needed
      }
  ]);

    // Navigate to the application URL
    await page.goto(applicationURL);

    // Other setup code...
});



test('@SP My Test', async ({ page }) => {
    page.route("https://rahulshettyacademy.com/api/ecom/order/get-orders-for-customer/*", async route => {
        const response = await page.request.fetch(route.request());
        let body = JSON.stringify(fakePayLoadOrders);
        route.fulfill(
          {
            response,
            body,
   
          });
    });

    await page.screenshot({ path: './screenshots/screenshot2.png' });

    await page.locator("button[routerlink*='myorders']").click();
    await page.waitForResponse("https://rahulshettyacademy.com/api/ecom/order/get-orders-for-customer/*");

    console.log(await page.locator(".mt-4").textContent());
});
