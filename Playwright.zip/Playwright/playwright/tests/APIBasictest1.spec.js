/**  
* @author Rajat Verma
* https://www.linkedin.com/in/rajat-v-3b0685128/
* https://github.com/rajatt95
* https://rajatt95.github.io/ 
*  
* Course: Playwright JS Automation Testing from Scratch with Framework (https://www.udemy.com/course/playwright-tutorials-automation-testing/)
* Tutor: Rahul Shetty (https://www.udemy.com/user/rahul445/)
*/

import { test, expect, request } from '@playwright/test';

let api_login_token;

// This is an Javascript object
const requestBody_Login = {
    userEmail: "likhit1993@gmail.com", 
    userPassword: "2024@Bhubaneswa"
};

test.beforeAll(async() => {

    const apiContext = await request.newContext({
        ignoreHTTPSErrors: true
    });
    
    
    const response_login = await apiContext.post(
        //Request URL
        'https://www.rahulshettyacademy.com/api/ecom/auth/login',
        { 
            //Request Body
            data: requestBody_Login
        })//post

        //Assertion for Response status code - 200
        expect(response_login.ok()).toBeTruthy();
        
        //Extract the Response Body in JSON format
        const response_login_json = await response_login.json();

        //Extract the token
        api_login_token = response_login_json.token; 

        console.log('api_login_token: '+api_login_token);
        
});

test.beforeEach(async ({page} )=> {

    

});

test('@Client App login', async ({ page }) => {

    page.addInitScript(value => {
        // Set the item in Local storage
        window.localStorage.setItem('token', value);
    }, api_login_token);

    console.log('api_login_token2: ' + api_login_token);

    const email = "likhit1993@gmail.com";
    const productName = 'ZARA COAT 3';
    const products = page.locator(".card-body");

    const applicationURL = "https://www.rahulshettyacademy.com/client/";
    await page.goto(applicationURL);

    await page.screenshot({ path: './screenshots/screenshot4.png' });

    const titles = await page.locator(".card-body b").allTextContents();
    console.log(titles);

    const count = await products.count();
    for (let i = 0; i < count; ++i) {
        if (await products.nth(i).locator("b").textContent() === productName) {
            //add to cart
            await products.nth(i).locator("text= Add To Cart").click();
            break;
        }
    }

    // Wait for the cart button to be visible
    await page.waitForSelector("[routerlink*='cart']");

    await page.locator("[routerlink*='cart']").click();

    page.setDefaultTimeout(50000);

    await page.screenshot({ path: './screenshots/screenshot3.png' });

    await page.locator("div li").first().waitFor();
    const bool = await page.locator("h3:has-text('zara coat 3')").isVisible();
    expect(bool).toBeTruthy();

    await page.locator("text=Checkout").click();

    await page.locator("[placeholder*='Country']").type("ind");

    const dropdown = page.locator(".ta-results");
    await dropdown.waitFor();

    const optionsCount = await dropdown.locator("button").count();
    for (let i = 0; i < optionsCount; ++i) {
        const text = await dropdown.locator("button").nth(i).textContent();
        if (text === " India") {
            await dropdown.locator("button").nth(i).click();
            break;
        }
    }

    expect(page.locator("label[type='text']")).toHaveText(email);

    await page.locator(".action__submit").click();

    await page.locator(".hero-primary").waitFor({ state: 'visible' });

    await expect(page.locator(".hero-primary")).toHaveText(" Thank you for the order. ");

    const orderId = await page.locator(".em-spacer-1 .ng-star-inserted").textContent();

    await page.locator(".btn.btn-custom[routerlink='/dashboard/myorders']").click();

    const verifyOrderID = await page.locator("tr.ng-star-inserted");
    const verifyOrderValue = await verifyOrderID.locator('th[scope="row"]').first().textContent();

    const cleanedTrimmedValue = verifyOrderValue.replace(/\s+/g, '');
    const cleanedTargetString = orderId.replace(/\|/g, '').replace(/\s+/g, '');

    if (cleanedTrimmedValue === cleanedTargetString) {
        await page.waitForSelector("td button.btn-primary");
        await page.locator("td button.btn-primary").first().click();
        return;
    }

    const orderIdDetails = await page.locator(".col-text").textContent();
    expect(orderId.includes(orderIdDetails)).toBeTruthy();

    // If the condition is false, the code below will be executed
    await page.pause();
});
