const {test,expect} = require('@playwright/test');

test('Section_07_RS_UI_Tests - RahulShettyAcademy Automation Practice App - Handle Alerts/Popu/Dialog', async ({page} )=> {

    const applicationURL = "https://rahulshettyacademy.com/AutomationPractice/";

    const btn_confirm = page.locator('#confirmbtn');
    
    await page.goto(applicationURL);


    

    page.on('dialog' , dialog => dialog.accept());
    clickOnElement(btn_confirm,'Confirm button');
    await waitForSomeTime(2);
    
});


async function clickOnElement(element,elementText) {
    console.log('Clicking on: '+elementText);
    await element.click();
}


async function waitForSomeTime(timeInSeconds) {
    console.log('Additional Wait for '+timeInSeconds+' seconds.');
    await new Promise(resolve => setTimeout(resolve, (timeInSeconds*1000)));
}