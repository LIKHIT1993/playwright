const { test, expect } = require('@playwright/test');
 
 
 
 
test('@Client App login', async ({ page }) => {
   //js file- Login js, DashboardPage
   const email = "anshika@gmail.com";
   const productName = 'ZARA COAT 3';
   const products = page.locator(".card-body");
   await page.goto("https://rahulshettyacademy.com/client");
   await page.locator("#userEmail").fill(email);
   await page.locator("#userPassword").type("Iamking@000");
   await page.locator("[value='Login']").click();
   await page.waitForLoadState('networkidle');
   const titles = await page.locator(".card-body b").allTextContents();
   console.log(titles);
   const count = await products.count();
   for (let i = 0; i < count; ++i) {
      if (await products.nth(i).locator("b").textContent() === productName) {
         //add to cart
         await products.nth(i).locator("text= Add To Cart").click();
         break;
      }
   }
 
   await page.locator("[routerlink*='cart']").click();
   //await page.pause();
   page.setDefaultTimeout(50000); // Set the default timeout to 50 seconds (50000 milliseconds)

   await page.locator("div li").first().waitFor();
   const bool = await page.locator("h3:has-text('zara coat 3')").isVisible();
   expect(bool).toBeTruthy();
   await page.locator("text=Checkout").click();
 
   await page.locator("[placeholder*='Country']").type("ind");
 
   const dropdown = page.locator(".ta-results");
   await dropdown.waitFor();
   const optionsCount = await dropdown.locator("button").count();
   for (let i = 0; i < optionsCount; ++i) {
      const text = await dropdown.locator("button").nth(i).textContent();
      if (text === " India") {
         await dropdown.locator("button").nth(i).click();
         break;
      }
   }
 
   expect(page.locator("label[type='text']")).toHaveText(email);
   await page.locator(".action__submit").click();
   await expect(page.locator(".hero-primary")).toHaveText(" Thankyou for the order. ");
   const orderId = await page.locator(".em-spacer-1 .ng-star-inserted").textContent();
   await page.locator(".btn.btn-custom[routerlink='/dashboard/myorders']").click();
   const verifyOrderID = await page.locator("tr.ng-star-inserted");
   const verifyOrderValue = await verifyOrderID.locator('th[scope="row"]').first().textContent();

   const cleanedTrimmedValue = verifyOrderValue.replace(/\s+/g, '');  // Remove all spaces
   const cleanedTargetString = orderId.replace(/\|/g, '').replace(/\s+/g, '') // Remove all spaces and | operator

  if (cleanedTrimmedValue === cleanedTargetString) {
  await page.waitForSelector("td button.btn-primary");
  await page.locator("td button.btn-primary").first().click();
  return; 
  }

  const orderIdDetails = await page.locator(".col-text").textContent();
   expect(orderId.includes(orderIdDetails)).toBeTruthy();

// If the condition is false, the code below will be executed
await page.pause();

 
 
});